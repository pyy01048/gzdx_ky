const s="/assets/mjs/pdf.worker.min-yatZIOMy.mjs";export{s as default};
