# -*- coding: utf-8 -*-
"""
P2-M5 代码上机 OJ：轻量级判题引擎

⚠️ 警告：此为开发/测试环境的简化实现，仅支持 Python 且无沙箱隔离。
生产环境必须替换为基于 Docker/Podman 的安全沙箱执行器。

支持的判题状态：
- AC (Accepted): 答案正确
- WA (Wrong Answer): 答案错误
- TLE (Time Limit Exceeded): 超时
- MLE (Memory Limit Exceeded): 超内存（暂未实现）
- CE (Compilation Error): 编译错误（Python 无编译阶段，跳过）
- RE (Runtime Error): 运行时错误
- SE (System Error): 系统错误
"""
from __future__ import annotations

import logging
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# 判题状态常量
STATUS_AC = "ac"
STATUS_WA = "wa"
STATUS_TLE = "tle"
STATUS_MLE = "mle"
STATUS_CE = "ce"
STATUS_RE = "re"
STATUS_SE = "se"


def judge_python_code(
    code: str,
    testcases: List[Dict[str, str]],
    time_limit_ms: int = 1000,
    memory_limit_kb: int = 256000,
) -> Dict[str, Any]:
    """判 Python 代码（简化版，无沙箱）。

    Args:
        code: 用户提交的 Python 代码
        testcases: 测试用例列表 [{"input": "...", "expected_output": "..."}, ...]
        time_limit_ms: 时限（毫秒）
        memory_limit_kb: 内存限制（KB，暂未强制限制）

    Returns:
        {
            "status": "ac" | "wa" | "tle" | "re" | "se",
            "passed": 通过的测试点数,
            "total": 总测试点数,
            "details": [{"testcase_id": ..., "status": ..., "time_ms": ..., "actual_output": ...}, ...],
            "max_time_ms": 最大耗时,
            "error_message": 错误信息（如有）
        }
    """
    results = []
    passed = 0
    max_time = 0
    compile_error = None

    # 步骤 1：语法检查（模拟编译）
    try:
        compile(code, "<submission>", "exec")
    except SyntaxError as e:
        compile_error = f"SyntaxError: {e.msg} (line {e.lineno})"
        return {
            "status": STATUS_CE,
            "passed": 0,
            "total": len(testcases),
            "details": [],
            "max_time_ms": 0,
            "compile_error": compile_error,
        }

    # 步骤 2：逐测试点执行
    for i, tc in enumerate(testcases):
        testcase_result = _run_single_testcase(code, tc["input"], tc["expected_output"], time_limit_ms)
        results.append(testcase_result)

        if testcase_result["status"] == STATUS_AC:
            passed += 1

        if testcase_result["time_ms"]:
            max_time = max(max_time, testcase_result["time_ms"])

        # 遇到非 AC 立即停止（可选策略）
        if testcase_result["status"] in (STATUS_RE, STATUS_SE):
            break

    # 步骤 3：汇总判定
    if passed == len(testcases):
        overall_status = STATUS_AC
    elif any(r["status"] == STATUS_TLE for r in results):
        overall_status = STATUS_TLE
    elif any(r["status"] == STATUS_RE for r in results):
        overall_status = STATUS_RE
    else:
        overall_status = STATUS_WA

    score = (passed / len(testcases) * 100) if testcases else 0.0

    return {
        "status": overall_status,
        "passed": passed,
        "total": len(testcases),
        "score": round(score, 1),
        "details": results,
        "max_time_ms": max_time,
        "error_message": next((r.get("error_message") for r in results if r.get("error_message")), None),
    }


def _run_single_testcase(
    code: str,
    input_data: str,
    expected_output: str,
    time_limit_ms: int,
) -> Dict[str, Any]:
    """运行单个测试用例。"""
    start_time = time.time()

    try:
        # 创建临时文件
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
            f.write(code)
            temp_file = f.name

        # 执行代码
        time_limit_sec = time_limit_ms / 1000.0
        result = subprocess.run(
            ["python", temp_file],
            input=input_data,
            capture_output=True,
            text=True,
            timeout=time_limit_sec,
            encoding="utf-8",
        )

        elapsed_ms = int((time.time() - start_time) * 1000)

        # 清理临时文件
        Path(temp_file).unlink(missing_ok=True)

        # 检查运行时错误
        if result.returncode != 0:
            return {
                "status": STATUS_RE,
                "time_ms": elapsed_ms,
                "memory_kb": None,
                "actual_output": None,
                "error_message": result.stderr[:500] if result.stderr else "Runtime Error",
            }

        # 对比输出（忽略首尾空白和行末换行）
        actual_output = result.stdout.strip()
        expected_clean = expected_output.strip()

        if actual_output == expected_clean:
            return {
                "status": STATUS_AC,
                "time_ms": elapsed_ms,
                "memory_kb": None,  # 简化版不统计内存
                "actual_output": None,  # AC 时不返回实际输出
                "error_message": None,
            }
        else:
            return {
                "status": STATUS_WA,
                "time_ms": elapsed_ms,
                "memory_kb": None,
                "actual_output": actual_output[:500],  # 截断避免过大
                "error_message": None,
            }

    except subprocess.TimeoutExpired:
        elapsed_ms = int((time.time() - start_time) * 1000)
        # 清理临时文件
        try:
            Path(temp_file).unlink(missing_ok=True)
        except Exception:
            pass
        return {
            "status": STATUS_TLE,
            "time_ms": elapsed_ms,
            "memory_kb": None,
            "actual_output": None,
            "error_message": f"Time Limit Exceeded ({time_limit_ms}ms)",
        }
    except Exception as e:
        elapsed_ms = int((time.time() - start_time) * 1000)
        # 清理临时文件
        try:
            Path(temp_file).unlink(missing_ok=True)
        except Exception:
            pass
        return {
            "status": STATUS_SE,
            "time_ms": elapsed_ms,
            "memory_kb": None,
            "actual_output": None,
            "error_message": f"System Error: {str(e)[:200]}",
        }
