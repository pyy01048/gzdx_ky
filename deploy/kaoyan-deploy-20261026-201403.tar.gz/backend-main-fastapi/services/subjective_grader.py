# -*- coding: utf-8 -*-
"""主观题 AI 批改公共服务（P0-2）。

模考引擎 ``services/exam_builder.py`` 里的 ``_ai_score_question`` 是模块私有
函数，且依赖模考 session 上下文。本模块把「题目 + 参考答案 + rubric +
考生答案 → 建议分」的 prompt 构造与 model_gateway 调用封装为公共函数
``grade_subjective``，供刷题流程的 ``POST /api/quiz/grade-subjective`` 使用。

设计：
- 不依赖模考 session 上下文，只依赖题目行（含 content/answer/analysis 等）。
- LLM 调用失败时返回 ``(None, 失败提示)``，由路由层组装降级响应，不抛异常。
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

#: 默认满分（题目/请求未给出 max_score 时）
DEFAULT_MAX_SCORE = 10.0


def _extract_score(text: str, max_score: float) -> Optional[float]:
    """从模型输出中提取 0~max_score 的建议分；提取失败返回 None。"""
    if not text:
        return None
    m = re.search(r"(\d+(?:\.\d+)?)", text)
    if not m:
        return None
    try:
        score = float(m.group(1))
    except (TypeError, ValueError):
        return None
    return max(0.0, min(max_score, score))


def grade_subjective(
    question: Any,
    my_answer: str,
    max_score: Optional[float] = None,
    db=None,
) -> Tuple[Optional[float], str]:
    """对一道主观题给出 AI 建议分与点评。

    Args:
        question: ORM 行（至少含 content/answer/analysis/subject 属性；
            也可传 dict，兼容模考快照形态）。
        my_answer: 考生答案文本。
        max_score: 满分；缺省用题目自带 max_score 或 ``DEFAULT_MAX_SCORE``。
        db: SQLAlchemy Session（model_gateway 云端供应商列表用）。

    Returns:
        ``(score, evaluation)``：
        - 成功：``(0~max_score 浮点分, 模型返回的原文点评)``；
        - 失败/无法提取：``(None, 降级提示语)``。
    """
    # —— 兼容 dict 与 ORM 两种题目形态 —— #
    if isinstance(question, dict):
        content = question.get("content") or ""
        answer = question.get("answer") or ""
        analysis = question.get("analysis") or ""
        subject = question.get("subject")
        q_max_score = question.get("max_score")
    else:
        content = getattr(question, "content", None) or ""
        answer = getattr(question, "answer", None) or ""
        analysis = getattr(question, "analysis", None) or ""
        subject = getattr(question, "subject", None)
        q_max_score = getattr(question, "max_score", None)

    try:
        max_score = float(max_score) if max_score is not None else (
            float(q_max_score) if q_max_score is not None else DEFAULT_MAX_SCORE
        )
    except (TypeError, ValueError):
        max_score = DEFAULT_MAX_SCORE
    if max_score <= 0:
        max_score = DEFAULT_MAX_SCORE

    user_answer = (my_answer or "").strip()
    if not user_answer:
        return None, "考生答案为空，无法批改"

    # —— 构造评分 prompt（与 exam_builder._ai_score_question 同源）—— #
    rubric_parts = []
    if answer:
        rubric_parts.append(f"参考答案：{str(answer)[:500]}")
    if analysis:
        rubric_parts.append(f"解析/评分要点：{str(analysis)[:500]}")
    rubric = "\n".join(rubric_parts) if rubric_parts else "无"

    prompt = (
        f"题目：{str(content)[:800]}\n"
        f"{rubric}\n"
        f"考生答案：{user_answer[:800]}\n"
        f"满分 {max_score} 分。请输出一个 0~{max_score} 的建议分数，"
        f"并给出简要点评（优缺点、改进建议，100 字以内）。"
    )

    try:
        from services.model_gateway import get_gateway

        res = get_gateway().chat(
            question=prompt,
            subject=subject,
            task="题目分析",
            context=None,
            system_prompt=(
                "你是考研阅卷老师，评分客观公正。"
                f"先输出建议分数（0~{max_score} 的数字），再输出点评。"
            ),
            prefer=None,
            db=db,
        )
        txt = (res.get("answer") or "").strip()
        if not txt:
            return None, "AI 批改暂不可用，请参考标准答案自评"

        score = _extract_score(txt, max_score)
        # 点评：去掉纯数字行，保留评语
        lines = [ln.strip() for ln in txt.splitlines() if ln.strip()]
        evaluation_lines = [
            ln for ln in lines if not re.fullmatch(r"\d+(?:\.\d+)?", ln)
        ]
        evaluation = "；".join(evaluation_lines)[:500] if evaluation_lines else txt[:500]
        if score is None:
            return None, evaluation or "AI 批改暂不可用，请参考标准答案自评"
        return score, evaluation
    except Exception as exc:  # noqa: BLE001 - LLM 失败不抛异常，由调用方降级
        logger.warning("主观题 AI 批改失败（已降级）: %s", exc)
        return None, "AI 批改暂不可用，请参考标准答案自评"